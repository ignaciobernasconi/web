// Por ahora no es necesario JS
console.log("Carrocerías Bernasconi - Página cargada correctamente 🚛");
